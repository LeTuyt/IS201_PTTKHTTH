/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAL;
import DTO.*;
import Utils.DBUtils;
import java.sql.*;

import java.util.ArrayList;
/**
 *
 * @author PC
 */
public class CanHoDAL {
    private DBUtils dbu = null;
    private Connection conn = null;
    private PreparedStatement pres = null;
    private ResultSet rs = null;
    
    
    public ArrayList<CanHo> dsCanHo(){
        String sql = "select MaCanHo, DienTich, Gia, TrangThai, SoPhong, MaCuDan, TenKhu from CanHo ch, KhuCanHo kch where ch.MaKhu = kch.MaKhu";
        ArrayList<CanHo> dsCanHo = new ArrayList<>();
        try{
            dbu = new DBUtils();
            conn = dbu.createConn();
            pres = conn.prepareStatement(sql);
            rs = pres.executeQuery();
            while (rs.next()){
                CanHo ch = new CanHo();
                ch.setMaCanHo(rs.getString(1));
                ch.setDienTich(rs.getFloat(2));
                ch.setGia(rs.getLong(3));
                ch.setTrangThai(rs.getBoolean(4));
                ch.setSoPhong(rs.getInt(5));
                ch.setMaCuDan(rs.getString(6));
                ch.setTenKhu(rs.getString(7));
                
                
                dsCanHo.add(ch);
            }
        } catch (SQLException e){
            e.printStackTrace();
            System.out.println("Error in CanHoDAL");
        }
        finally{
            try{
                conn.close();
                pres.close();
                rs.close();
            } catch (SQLException e){
                e.printStackTrace();
            }
        }
        return dsCanHo;
        
    }
    
    public boolean inserts(ArrayList<CanHo> list){
        String sql = "INSERT [dbo].[CANHO] ([MaCanHo], [DienTich], [Gia], [TrangThai], [SoPhong], [MaCuDan], [MaKhu])"
                       + "VALUES (?, ?, ?, ?, ?, ?, ?)";
           try{ 
            for(CanHo c : list){
               dbu = new DBUtils();
               conn = dbu.createConn();
               pres = conn.prepareStatement(sql);

               
                
               pres.setString(1, c.getMaCanHo());
               pres.setFloat(2, c.getDienTich());
               pres.setLong(3,c.getGia());
               pres.setBoolean(4, c.isTrangThai());
               pres.setInt(5, c.getSoPhong());
               pres.setString(6, c.getMaCuDan());
               pres.setString(7, c.getMaKhu());
               
               pres.executeUpdate();
 
            }
            return true;
              
        } catch (SQLException e) {
            return false;
        }
    }
}
