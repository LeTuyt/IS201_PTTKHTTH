/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;
import DTO.*;
import BLL.*;
import java.awt.Image;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

        
/**
 *
 * @author PC
 */
public class NhanVienGUI1 extends javax.swing.JFrame {

    /**
     * Creates new form NhanVienGUI
     */
    public NhanVienGUI1() {
        initComponents();
        setTitle("Nhân viên");
        setSize(1254,950);
        LoadTableTTMB();
        LoadTableQLCD();
        LoadTableTTCH();
        setVisible(true);
        
        
        ImageIcon icon = new ImageIcon ("D:\\Study\\Java\\Final_Project\\logo-anland-complex.png");
        Image img = icon.getImage();
        Image imgScale = img.getScaledInstance(inhopdong2.getWidth(), inhopdong2.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgScale);
        inhopdong2.setIcon(scaledIcon);
        
//        ImageIcon tabicon = new ImageIcon ("D:\\Study\\Java\\Final_Project\\mautrang.png");
//        Image imga = tabicon.getImage();
//        Image imgScaled = imga.getScaledInstance(tabThongTinMuaBan.getWidth(), tabThongTinMuaBan.getHeight(), Image.SCALE_SMOOTH);
//        ImageIcon scaledIconblue = new ImageIcon(imgScaled);
//        tabThongTinMuaBan.setIcon(scaledIconblue);
    }

    DefaultTableModel tblModelThongTinMuaBan;
    public void LoadTableTTMB(){
        tblModelThongTinMuaBan = new DefaultTableModel();
        
        String tieude[] = {"Mã hợp đồng", "Tên khách hàng", "Mã căn hộ", "Mã cư dân", "Địa chỉ khách hàng", "Giá", "Ngày giao dịch"};
        tblModelThongTinMuaBan.setColumnIdentifiers(tieude);
        
        ArrayList<HopDong> arr = new ArrayList<HopDong>();
        
        ThongTinMuaBanBLL ThongTin_MuaBanBLL = new ThongTinMuaBanBLL();
        arr = ThongTin_MuaBanBLL.dsHopDong();
        HopDong hd = new HopDong();
        for (int i = 0; i < arr.size(); i++ ){
            hd = arr.get(i);
            String MaHopDong = hd.getMaHopDong();
            String TenKH = hd.getTenKH();
            String MaCanHo = hd.getMaCanHo();
            String MaCuDan = hd.getMaCuDan();
            String DiaChi = hd.getDiaChiKhachHang();
            int Gia = hd.getGia();
            String NgayGiaoDich = hd.getNgayGiaoDich();
            Object[] row = {MaHopDong, TenKH, MaCanHo, MaCuDan, DiaChi, Gia, NgayGiaoDich};
            
            tblModelThongTinMuaBan.addRow(row);
        }
        tblThongTinMuaBan.setModel(tblModelThongTinMuaBan);
        setVisible(true);
            
    }
    DefaultTableModel tblModelQuanLyCuDan;
    public void LoadTableQLCD(){
        tblModelQuanLyCuDan = new DefaultTableModel();
        String tieude[] ={"Mã cư dân"," Tên cư dân", "Ngày sinh", "Giới tính", "Số điện thoại", "Số CMT", "Quê quán"};
        tblModelQuanLyCuDan.setColumnIdentifiers(tieude);
        ArrayList<CuDan> arr = new ArrayList<CuDan>();
        QuanLyCuDanBLL QuanLy_CuDanBLL = new QuanLyCuDanBLL();
        arr = QuanLy_CuDanBLL.ListCuDan();
        CuDan cd = new CuDan();
        for (int i = 0; i< arr.size(); i++){
            cd = arr.get(i);
            String MaCuDan = cd.getMaCuDan();
            String TenCuDan = cd.getTenCuDan();
            String NgaySinh = cd.getNgaySinh();
            Boolean GioiTinh = cd.isGioiTinh();
            String SoDT = cd.getSoDT();
            String SoCMT = cd.getSoCMT();
            String QueQuan = cd.getQueQuan();
            Object[] row ={MaCuDan, TenCuDan, NgaySinh, GioiTinh, SoDT, SoCMT, QueQuan};
            tblModelQuanLyCuDan.addRow(row);
        }
        tblQuanLyCuDan.setModel(tblModelQuanLyCuDan);
        setVisible(true);
    }
    DefaultTableModel tblModelThongTinCanHo;
    public void LoadTableTTCH(){
       tblModelThongTinCanHo = new DefaultTableModel();
       String tieude[] = {"Mã căn hộ", "Diện tích", "Giá", "Số phòng", "Tên khu"};
       tblModelThongTinCanHo.setColumnIdentifiers(tieude);
       ArrayList<CanHo> arr = new ArrayList<CanHo>();
       ThongTinCanHoBLL ThongTin_CanHoBLL = new ThongTinCanHoBLL();
       arr = ThongTin_CanHoBLL.dsCanHo();
       CanHo ch = new CanHo();
       for (int i = 0; i < arr.size(); i++){
           ch = arr.get(i);
           String MaCanHo = ch.getMaCanHo();
           float DienTich = ch.getDienTich();
           long Gia = ch.getGia();
           int SoPhong = ch.getSoPhong();
           String TenKhu = ch.getTenKhu();
           Object[] row = {MaCanHo, DienTich, Gia, SoPhong, TenKhu};
           tblModelThongTinCanHo.addRow(row);
           
       }
       tblThongTinCanHo.setModel(tblModelThongTinCanHo);
       setVisible(true);
       
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnLogout = new javax.swing.JButton();
        tabNhanVien = new javax.swing.JTabbedPane();
        tabQuanLyCuDan = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtMaCD = new javax.swing.JTextField();
        txtTenCD = new javax.swing.JTextField();
        cbbGioiTinh = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtSDT = new javax.swing.JTextField();
        txtQueQuan = new javax.swing.JTextField();
        txtSoCM = new javax.swing.JTextField();
        btnUpdate = new javax.swing.JButton();
        DatNgSinh = new com.toedter.calendar.JDateChooser();
        jLabel13 = new javax.swing.JLabel();
        txtTimKiem1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblQuanLyCuDan = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        tabThongTinCanHo = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblThongTinCanHo = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        cbbDienTich = new javax.swing.JComboBox<>();
        cbbGia = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        cbbSoPhong = new javax.swing.JComboBox<>();
        btnTimKiem = new javax.swing.JButton();
        hjhj = new javax.swing.JPanel();
        inhopdong = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        txtMaCanHo = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        txtGiaCanHo = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        datNGD = new com.toedter.calendar.JDateChooser();
        jLabel22 = new javax.swing.JLabel();
        cbbMaCD = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        txtTenKH = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        datNgSinh = new com.toedter.calendar.JDateChooser();
        jLabel25 = new javax.swing.JLabel();
        cbbGioiTinh1 = new javax.swing.JComboBox<>();
        jLabel26 = new javax.swing.JLabel();
        txtSoDT = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        txtSoCMND = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtDiaChi = new javax.swing.JTextField();
        inhopdong2 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        btnInHopDong = new javax.swing.JButton();
        tabThongTinMuaBan = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        JScrollPane = new javax.swing.JScrollPane();
        tblThongTinMuaBan = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        nhanvien1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        btnLogout.setFont(new java.awt.Font("sansserif", 1, 16)); // NOI18N
        btnLogout.setText("Đăng xuất");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        jPanel1.add(btnLogout);
        btnLogout.setBounds(1030, 110, 170, 38);

        tabQuanLyCuDan.setBackground(new java.awt.Color(64, 75, 105));

        jLabel6.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel6.setText("Mã cư dân");
        jLabel6.setPreferredSize(new java.awt.Dimension(70, 40));

        jLabel7.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel7.setText("Tên cư dân");

        jLabel8.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel8.setText("Ngày sinh");

        jLabel9.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel9.setText("Giới tính");

        cbbGioiTinh.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel10.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel10.setText("Số điện thoại");

        jLabel11.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel11.setText("Quê quán");

        jLabel12.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel12.setText("Số CMND");

        btnUpdate.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        btnUpdate.setText("Cập nhật thông tin");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(338, 338, 338)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtMaCD)
                    .addComponent(txtTenCD)
                    .addComponent(cbbGioiTinh, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DatNgSinh, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel12)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(40, 40, 40)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtSDT)
                            .addComponent(txtQueQuan)
                            .addComponent(txtSoCM, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(btnUpdate)))
                .addContainerGap(330, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMaCD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel11)
                        .addComponent(txtQueQuan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(txtTenCD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel12)
                    .addComponent(DatNgSinh, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSoCM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel9)
                        .addComponent(cbbGioiTinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnUpdate))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jLabel13.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Tìm kiếm");

        tblQuanLyCuDan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblQuanLyCuDan);

        jLabel5.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Thông tin cư dân");

        javax.swing.GroupLayout tabQuanLyCuDanLayout = new javax.swing.GroupLayout(tabQuanLyCuDan);
        tabQuanLyCuDan.setLayout(tabQuanLyCuDanLayout);
        tabQuanLyCuDanLayout.setHorizontalGroup(
            tabQuanLyCuDanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabQuanLyCuDanLayout.createSequentialGroup()
                .addGroup(tabQuanLyCuDanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabQuanLyCuDanLayout.createSequentialGroup()
                        .addGap(520, 520, 520)
                        .addComponent(jLabel5)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(tabQuanLyCuDanLayout.createSequentialGroup()
                .addContainerGap(366, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGap(28, 28, 28)
                .addComponent(txtTimKiem1, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(429, 429, 429))
        );
        tabQuanLyCuDanLayout.setVerticalGroup(
            tabQuanLyCuDanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabQuanLyCuDanLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel5)
                .addGap(24, 24, 24)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(tabQuanLyCuDanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtTimKiem1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 398, Short.MAX_VALUE)
                .addGap(18, 18, 18))
        );

        tabNhanVien.addTab("Quản lý cư dân", tabQuanLyCuDan);

        tabThongTinCanHo.setBackground(new java.awt.Color(64, 75, 105));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Thông Tin Căn Hộ");

        jScrollPane2.setViewportBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 102, 51)));

        tblThongTinCanHo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tblThongTinCanHo);

        jLabel15.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel15.setText("Diện tích");

        jLabel16.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel16.setText("Giá");

        cbbDienTich.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbbGia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel17.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel17.setText("Số phòng");

        cbbSoPhong.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnTimKiem.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        btnTimKiem.setText("Tìm Kiếm");
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(cbbDienTich, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(cbbGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel16)
                        .addGap(18, 18, 18)))
                .addGap(39, 39, 39)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(cbbSoPhong, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addComponent(btnTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(646, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbbDienTich, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbSoPhong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiem))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout tabThongTinCanHoLayout = new javax.swing.GroupLayout(tabThongTinCanHo);
        tabThongTinCanHo.setLayout(tabThongTinCanHoLayout);
        tabThongTinCanHoLayout.setHorizontalGroup(
            tabThongTinCanHoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabThongTinCanHoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabThongTinCanHoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(tabThongTinCanHoLayout.createSequentialGroup()
                        .addGroup(tabThongTinCanHoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(tabThongTinCanHoLayout.createSequentialGroup()
                                .addGap(351, 351, 351)
                                .addComponent(jLabel14))
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(27, Short.MAX_VALUE))))
        );
        tabThongTinCanHoLayout.setVerticalGroup(
            tabThongTinCanHoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabThongTinCanHoLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 541, Short.MAX_VALUE))
        );

        tabNhanVien.addTab("Thông tin căn hộ", tabThongTinCanHo);

        hjhj.setBackground(new java.awt.Color(64, 75, 105));
        hjhj.setBorder(javax.swing.BorderFactory.createCompoundBorder());

        inhopdong.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel19.setText("Mã căn hộ");

        jLabel20.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel20.setText("Giá căn hộ");

        jLabel21.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel21.setText("Ngày giao dịch");

        jLabel22.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel22.setText("Mã cư dân");

        cbbMaCD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel23.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel23.setText("Tên khách hàng");

        jLabel24.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel24.setText("Ngày sinh");

        jLabel25.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel25.setText("Giới tính");

        cbbGioiTinh1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbbGioiTinh1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbGioiTinh1ActionPerformed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel26.setText("SĐT");

        txtSoDT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSoDTActionPerformed(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel27.setText("Số CMND");

        jLabel28.setFont(new java.awt.Font("sansserif", 0, 20)); // NOI18N
        jLabel28.setText("Địa chỉ");

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 51, 0));
        jLabel2.setText("HỢP ĐỒNG MUA NHÀ");

        javax.swing.GroupLayout inhopdongLayout = new javax.swing.GroupLayout(inhopdong);
        inhopdong.setLayout(inhopdongLayout);
        inhopdongLayout.setHorizontalGroup(
            inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inhopdongLayout.createSequentialGroup()
                .addComponent(inhopdong2, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(inhopdongLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inhopdongLayout.createSequentialGroup()
                        .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel27)
                            .addComponent(jLabel28)
                            .addGroup(inhopdongLayout.createSequentialGroup()
                                .addComponent(jLabel22)
                                .addGap(122, 122, 122)
                                .addComponent(cbbMaCD, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(inhopdongLayout.createSequentialGroup()
                                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel24)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel26))
                                .addGap(79, 79, 79)
                                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(datNgSinh, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                                    .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtSoCMND, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtSoDT, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtTenKH)
                                    .addComponent(cbbGioiTinh1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 35, Short.MAX_VALUE))
                    .addGroup(inhopdongLayout.createSequentialGroup()
                        .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inhopdongLayout.createSequentialGroup()
                                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel21))
                                .addGap(88, 88, 88)
                                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtGiaCanHo)
                                    .addComponent(datNGD, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(inhopdongLayout.createSequentialGroup()
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(83, 83, 83)
                                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(inhopdongLayout.createSequentialGroup()
                                        .addComponent(txtMaCanHo, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addContainerGap())))
        );
        inhopdongLayout.setVerticalGroup(
            inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inhopdongLayout.createSequentialGroup()
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(inhopdong2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(inhopdongLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtMaCanHo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addGap(28, 28, 28)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(txtGiaCanHo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addComponent(datNGD, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbbMaCD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22))
                .addGap(18, 18, 18)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addComponent(txtTenKH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel24)
                    .addComponent(datNgSinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel25)
                    .addComponent(cbbGioiTinh1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSoDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(txtSoCMND, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(inhopdongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28))
        );

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Thông tin hợp đồng");

        btnInHopDong.setText("In hợp đồng");
        btnInHopDong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInHopDongActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout hjhjLayout = new javax.swing.GroupLayout(hjhj);
        hjhj.setLayout(hjhjLayout);
        hjhjLayout.setHorizontalGroup(
            hjhjLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hjhjLayout.createSequentialGroup()
                .addGroup(hjhjLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(hjhjLayout.createSequentialGroup()
                        .addGap(478, 478, 478)
                        .addComponent(btnInHopDong, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(hjhjLayout.createSequentialGroup()
                        .addGap(324, 324, 324)
                        .addComponent(inhopdong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(hjhjLayout.createSequentialGroup()
                        .addGap(498, 498, 498)
                        .addComponent(jLabel18)))
                .addContainerGap(360, Short.MAX_VALUE))
        );
        hjhjLayout.setVerticalGroup(
            hjhjLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(hjhjLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel18)
                .addGap(33, 33, 33)
                .addComponent(inhopdong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnInHopDong)
                .addContainerGap(75, Short.MAX_VALUE))
        );

        tabNhanVien.addTab("In hợp đồng", hjhj);

        tabThongTinMuaBan.setBackground(new java.awt.Color(64, 75, 105));
        tabThongTinMuaBan.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Thông Tin Mua Bán");
        jLabel3.setMaximumSize(new java.awt.Dimension(200, 30));
        tabThongTinMuaBan.add(jLabel3);
        jLabel3.setBounds(530, 40, 190, 24);

        jLabel4.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Tìm kiếm");
        tabThongTinMuaBan.add(jLabel4);
        jLabel4.setBounds(41, 50, 80, 24);
        tabThongTinMuaBan.add(txtTimKiem);
        txtTimKiem.setBounds(130, 40, 210, 28);

        JScrollPane.setBackground(new java.awt.Color(255, 255, 255));

        tblThongTinMuaBan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        JScrollPane.setViewportView(tblThongTinMuaBan);

        tabThongTinMuaBan.add(JScrollPane);
        JScrollPane.setBounds(0, 150, 1250, 510);

        tabNhanVien.addTab("Thông tin mua bán", tabThongTinMuaBan);

        jPanel1.add(tabNhanVien);
        tabNhanVien.setBounds(-10, 150, 1250, 780);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logo-anland-complex.png"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(10, 10, 449, 150);

        nhanvien1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(nhanvien1);
        nhanvien1.setBounds(0, 10, 1230, 390);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1210, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 861, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        // TODO add your handling code here:

        this.dispose();
        DangNhapGUI dn = new DangNhapGUI();
        dn.setVisible(true);
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnInHopDongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInHopDongActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnInHopDongActionPerformed

    private void cbbGioiTinh1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbGioiTinh1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbbGioiTinh1ActionPerformed

    private void txtSoDTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSoDTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSoDTActionPerformed

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnTimKiemActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // TODO add your handling code here:
         CuDan cd = new CuDan();
        cd.setMaCuDan(Integer.parseInt(txtMaCD.getText()));
        cd.setTenCuDan(txtTenCD.getText());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(DatNgSinh.getDate());
        cd.setNgaySinh(date);
        cd.setGioiTinh(cbbGioiTinh.getSelectedItem().toString());
        cd.setSoDT(txtSDT.getText());
        cd.setSoCMT(txtSoCM.getText());
        cd.setQueQuan(txtQueQuan.getText());
        
        try{
            int result = QuanLy_CuDanBLL.UpdateCuDan(cd);
            if (result !=0 ){
                JOptionPane.showMessageDialog(null, "Cập nhật dữ liệu thành công!","Thông báo", JOptionPane.INFORMATION_MESSAGE);
                
            }
            LoadTableQLCD(QuanLy_CuDanBLL.dsCuDan());
        } catch (Exception ex){
            ex.printStackTrace();
        }
        
        
    }//GEN-LAST:event_btnUpdateActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NhanVienGUI1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NhanVienGUI1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NhanVienGUI1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NhanVienGUI1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NhanVienGUI1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser DatNgSinh;
    private javax.swing.JScrollPane JScrollPane;
    private javax.swing.JButton btnInHopDong;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cbbDienTich;
    private javax.swing.JComboBox<String> cbbGia;
    private javax.swing.JComboBox<String> cbbGioiTinh;
    private javax.swing.JComboBox<String> cbbGioiTinh1;
    private javax.swing.JComboBox<String> cbbMaCD;
    private javax.swing.JComboBox<String> cbbSoPhong;
    private com.toedter.calendar.JDateChooser datNGD;
    private com.toedter.calendar.JDateChooser datNgSinh;
    private javax.swing.JPanel hjhj;
    private javax.swing.JPanel inhopdong;
    private javax.swing.JLabel inhopdong2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel nhanvien1;
    private javax.swing.JTabbedPane tabNhanVien;
    private javax.swing.JPanel tabQuanLyCuDan;
    private javax.swing.JPanel tabThongTinCanHo;
    private javax.swing.JPanel tabThongTinMuaBan;
    private javax.swing.JTable tblQuanLyCuDan;
    private javax.swing.JTable tblThongTinCanHo;
    private javax.swing.JTable tblThongTinMuaBan;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtGiaCanHo;
    private javax.swing.JTextField txtMaCD;
    private javax.swing.JTextField txtMaCanHo;
    private javax.swing.JTextField txtQueQuan;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txtSoCM;
    private javax.swing.JTextField txtSoCMND;
    private javax.swing.JTextField txtSoDT;
    private javax.swing.JTextField txtTenCD;
    private javax.swing.JTextField txtTenKH;
    private javax.swing.JTextField txtTimKiem;
    private javax.swing.JTextField txtTimKiem1;
    // End of variables declaration//GEN-END:variables
}
